define(["module", "require", "exports"], (function(e, n, t) {
    function r(e, n) {
        return new Promise((t => {
            e.addEventListener("message", (function r({
                data: o
            }) {
                null != o && o.type === n && (e.removeEventListener("message", r), t(o))
            }))
        }))
    }
    let o;
    r(self, "wasm_bindgen_worker_init").then((async e => {
        const n = await Promise.resolve().then((function() {
            return h
        }));
        await n.default(e.module, e.memory), postMessage({
            type: "wasm_bindgen_worker_ready"
        }), n.wbg_rayon_start_worker(e.receiver)
    }));
    let i = new TextDecoder("utf-8", {
        ignoreBOM: !0,
        fatal: !0
    });
    i.decode();
    let a = null;

    function s() {
        return null !== a && a.buffer === o.__wbindgen_export_0.buffer || (a = new Uint8Array(o.__wbindgen_export_0.buffer)), a
    }
    const _ = new Array(32).fill(void 0);
    _.push(void 0, null, !0, !1);
    let u = _.length;

    function l(e) {
        u === _.length && _.push(_.length + 1);
        const n = u;
        return u = _[n], _[n] = e, n
    }
    let c = 0;
    let w = null;

    function b() {
        return null !== w && w.buffer === o.__wbindgen_export_0.buffer || (w = new Int32Array(o.__wbindgen_export_0.buffer)), w
    }

    function d(e, n, t, r, i) {
        try {
            const g = o.__wbindgen_add_to_stack_pointer(-16);
            var a = function(e, n) {
                    const t = n(1 * e.length);
                    return s().set(e, t / 1), c = e.length, t
                }(e, o.__wbindgen_malloc),
                _ = c;
            o.optimise(g, a, _, n, t, r, i);
            var u = b()[g / 4 + 0],
                l = b()[g / 4 + 1],
                w = (d = u, f = l, s().subarray(d / 1, d / 1 + f)).slice();
            return o.__wbindgen_free(u, 1 * l), w
        } finally {
            o.__wbindgen_add_to_stack_pointer(16)
        }
        var d, f
    }

    function f(e) {
        const n = function(e) {
            return _[e]
        }(e);
        return function(e) {
            e < 36 || (_[e] = u, u = e)
        }(e), n
    }

    function g(e) {
        return f(o.initThreadPool(e))
    }

    function m(e) {
        o.wbg_rayon_start_worker(e)
    }
    class y {
        static __wrap(e) {
            const n = Object.create(y.prototype);
            return n.ptr = e, n
        }
        __destroy_into_raw() {
            const e = this.ptr;
            return this.ptr = 0, e
        }
        free() {
            const e = this.__destroy_into_raw();
            o.__wbg_wbg_rayon_poolbuilder_free(e)
        }
        numThreads() {
            return o.wbg_rayon_poolbuilder_numThreads(this.ptr) >>> 0
        }
        receiver() {
            return o.wbg_rayon_poolbuilder_receiver(this.ptr)
        }
        build() {
            o.wbg_rayon_poolbuilder_build(this.ptr)
        }
    }
    async function p(n, t) {
        void 0 === n && (n = new URL("./squoosh_oxipng_bg-5c8fadb7.wasm", e.uri));
        const a = {
            wbg: {}
        };
        a.wbg.__wbindgen_throw = function(e, n) {
            throw new Error((t = e, r = n, i.decode(s().slice(t, t + r))));
            var t, r
        }, a.wbg.__wbindgen_module = function() {
            return l(p.__wbindgen_wasm_module)
        }, a.wbg.__wbindgen_memory = function() {
            return l(o.__wbindgen_export_0)
        }, a.wbg.__wbg_startWorkers_914655bb4d5bb5e1 = function(n, t, o) {
            var i = async function(n, t, o) {
                const i = {
                    type: "wasm_bindgen_worker_init",
                    module: n,
                    memory: t,
                    receiver: o.receiver()
                };
                try {
                    await Promise.all(Array.from({
                        length: o.numThreads()
                    }, (() => {
                        const n = new Worker(new URL("./workerHelpers-0eac9207.js", e.uri));
                        return n.postMessage(i), r(n, "wasm_bindgen_worker_ready")
                    }))), o.build()
                } finally {
                    o.free()
                }
            }(f(n), f(t), y.__wrap(o));
            return l(i)
        }, ("string" == typeof n || "function" == typeof Request && n instanceof Request || "function" == typeof URL && n instanceof URL) && (n = fetch(n)), a.wbg.memory = t || new WebAssembly.Memory({
            initial: 17,
            maximum: 16384,
            shared: !0
        });
        const {
            instance: _,
            module: u
        } = await async function(e, n) {
            if ("function" == typeof Response && e instanceof Response) {
                if ("function" == typeof WebAssembly.instantiateStreaming) try {
                    return await WebAssembly.instantiateStreaming(e, n)
                } catch (n) {
                    if ("application/wasm" == e.headers.get("Content-Type")) throw n;
                    console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", n)
                }
                const t = await e.arrayBuffer();
                return await WebAssembly.instantiate(t, n)
            } {
                const t = await WebAssembly.instantiate(e, n);
                return t instanceof WebAssembly.Instance ? {
                    instance: t,
                    module: e
                } : t
            }
        }(await n, a);
        return o = _.exports, p.__wbindgen_wasm_module = u, o.__wbindgen_start(), o
    }
    var h = Object.freeze({
        __proto__: null,
        optimise: d,
        initThreadPool: g,
        wbg_rayon_start_worker: m,
        wbg_rayon_PoolBuilder: y,
        default: p
    });
    t.default = p, t.initThreadPool = g, t.optimise = d, t.wbg_rayon_PoolBuilder = y, t.wbg_rayon_start_worker = m
}));